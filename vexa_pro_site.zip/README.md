# VEXA — Site Profissional

Pacote com 5 páginas HTML prontas para publicar (tema dark, logo VEXA, botões com gradiente e animações suaves).

**Páginas incluídas:**
- index.html (Início)
- sobre.html (Sobre)
- trabalhos.html (Trabalhos)
- servicos.html (Serviços)
- contato.html (Contato)

**Como publicar (GitHub Pages):**
1. Crie um repositório no GitHub.
2. Faça upload desses arquivos (index.html e demais).
3. Ative GitHub Pages em _Settings → Pages_ apontando para a branch `main`.
4. Acesse `https://<seu-usuario>.github.io/<nome-do-repo>/`

**Observações:**
- Imagens e vídeo são carregados via links externos (hotlinks). Se preferir, faça upload das imagens no repositório e atualize os caminhos.
- O vídeo do projeto usa um iframe do Google Drive (precisa estar com acesso público para funcionar).
